<?php
// необходимые HTTP-заголовки 
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

// код ответа - 404 Ничего не найдено 
http_response_code(400);

// сообщение об ошибке
echo json_encode(array("message" => "Некорректный запрос"), JSON_UNESCAPED_UNICODE);
?>